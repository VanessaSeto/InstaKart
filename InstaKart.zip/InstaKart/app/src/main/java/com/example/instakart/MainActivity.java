package com.example.instakart;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.EditText;
import android.support.v7.app.ActionBar;
import androidmads.library.qrgenearator.QRGContents;
import androidmads.library.qrgenearator.QRGEncoder;
import android.graphics.Bitmap;
import androidmads.library.qrgenearator.QRGSaver;
import android.content.Intent;
import android.graphics.BitmapFactory;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayOutputStream;

public class MainActivity extends AppCompatActivity {
    Bitmap bitmap;
    List<String> groceryList = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent loadIntent = new Intent(MainActivity.this, openingscreen.class);
        startActivity(loadIntent);

        View decorView = getWindow().getDecorView();
        // Hide the status bar.
        int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
        decorView.setSystemUiVisibility(uiOptions);
        // Remember that you should never show the action bar if the
        // status bar is hidden, so hide that too if necessary.
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        final ListView lv = (ListView) findViewById(R.id.list);
        final ArrayAdapter<String> aad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, groceryList);
        lv.setAdapter(aad);
        final Button btn = (Button) findViewById(R.id.button);
        final EditText input = (EditText)findViewById(R.id.grocery_item_enter);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                String text = input.getText().toString();
                if(text.length() != 0) {
                    groceryList.add(text);
                    aad.notifyDataSetChanged();
                }

                input.setText("");

            }
        });

        final Button qr = (Button) findViewById(R.id.generate_qr);
        qr.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String inputValue = groceryList.toString();
                QRGEncoder qrgEncoder = new QRGEncoder(inputValue, null, QRGContents.Type.TEXT, 800);
                try {
                    // Getting QR-Code as Bitmap
                    bitmap = qrgEncoder.encodeAsBitmap();
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    byte[] byteArray = stream.toByteArray();
                    Intent intent = new Intent(MainActivity.this, QRCode.class);
                    intent.putExtra("picture", byteArray);
                    startActivity(intent);
                } catch(com.google.zxing.WriterException e){
                }

            }
        });

    }

}
